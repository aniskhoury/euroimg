<?php
if (!isset($_SESSION)){
	//S'inicialitza sessió amb usuari anònim
	session_start();
	$_SESSION['idusuari'] = -1;
}

$usuari   = "euroimg";
$clau     = "euroimg";
$bbdd     = "euroimg";
$servidor = "localhost";
$conexio = new mysqli($servidor, $usuari, $clau, $bbdd);
if ($conexio->connect_errno) {
    echo "Fallo al conectar a MySQL: " . $mysqli->connect_error;
}
$resultat = $conexio->query("SELECT * FROM llicencies");
echo "<br><br><br><br><br>";
$c = 0;
while ($obj = $resultat->fetch_object()){
		echo $c;
		echo $obj->nom;
		$c = $c+1;
}

?>