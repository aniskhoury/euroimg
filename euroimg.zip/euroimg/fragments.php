<?php
/*  #######################################################
	##  Fragments de codi per modularitzar la pàgina web ##
	#######################################################
	##               Autor: Anïs Khoury Ribas            ##
	##               Per Meinsa Sistemas S.L.            ##
	#######################################################
	
*/

function fragmentNavegador($codiLlengua){
	$resultat = '  <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#adalt-de-tot">EuroIMG</a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="galeria/">Galeria de euroImages</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="sobreeuroimg/">Sobre EuroIMG</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="contacta/">Contacta</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>';
  return $resultat;
}

function fragmentCapceleraInici($codiLlengua){
	$resultat = '  <header class="masthead bg-primary text-white text-center">
					<center>
					<form name="formulariPujarFitxers" id="formulariPujarFitxers" method="post" action="desarfitxer.php" enctype="multipart/form-data">
						
						<h4 class="text-center">Cargar Multiple Archivos</h4>
						
						<div class="form-group">
							<label class="col-sm-2 control-label">Archivos</label>
							<div class="col-sm-8">
								<input type="file" class="form-control" id="fitxers[]" name="fitxers[]" multiple="">
							</div>
							<br>
							<button type="submit" class="btn btn-success">Cargar</button>
						</div>
						
					</form>
					</center>
	</div>
      <!-- Icon Divider -->
      <div class="divider-custom divider-light">
        <div class="divider-custom-line"></div>

        <div class="divider-custom-line"></div>
      </div>

		<!-- Masthead Subheading -->
		<p>0) Toda la web y los servicios de EuroIMG son GPL y el contenido Creative Commons </p>
		<p>1) <b>Tenemos los servidores en Europa</b>. No ponemos tus datos en Amazon cloud, Microsoft Azure, etc.<br></p>
		<p>2) <b>Seguimos las leyes Europeas de privacidad</b>. Solamente entregamos datos con orden judicial, a diferencia de ciertos paises anglosajones.<br></p>
		<p>3) Estamos enfocados a las directrices de la Unión Europea: <b>Libre circulación de personas, capitales e información</b>.<br>
		<p>4) Nos enfocamos en dar servicios a los ciudadanos europeos<br>
		<p>5) No nos apropiamos de las imagenes. <b>Los derechos (de la propiedad, explotación y autoría) de las imagenes subidas por los usuarios se respetan</b>.<br>
		<p>6) La responsabilidad del uso del servicio recae en el usuario que ha subido la imagen.<br>
		<p>7) <b>Pagamos impuestos en Europa</b>y nuestros trabajadores cotizan en Estados y países de la Unión Europea<br>
		<p>8) <b>Trabajamos con el euro</b>. El ingreso con otras divisas lo aceptamos, pero <b>será convertido en euros</b>.<br>
		<p>9) Pensado para diseñadores gráficos, fotógrafos, ilustradores y artistas.
		<p>10) Tratamos de hacer una empresa inclusiva, aceptando la diversidad humana, lingüística y cultural de los países de la Unión Europea.
    </div>
  </header>';
  return $resultat;
}

function fragmentPeuPaginaInici($codiLlengua){
	$resultat = '  <footer class="footer text-center">
    <div class="container">
      <div class="row">

        <!-- Footer Location -->
        <div class="col-lg-4 mb-5 mb-lg-0">
          <h4 class="text-uppercase mb-4">Dirección</h4>
          <p class="lead mb-0">C/ Girona, 63
            <br>08009 , Barcelona</p>
        </div>

        <!-- Footer Social Icons -->
        <div class="col-lg-4 mb-5 mb-lg-0">
		<h4 class="text-uppercase mb-4">Privacidad</h4>
			Estamos comprometidos con la privacidad de nuestros usuarios. Seas fotógrafo, diseñador, artista o usuario particular
        </div>

        <!-- Footer About Text -->
        <div class="col-lg-4">
          <h4 class="text-uppercase mb-4">Licencia</h4>
          <p class="lead mb-0">GPL para el código y Creative Commons para el contenido.

        </div>

      </div>
    </div>
  </footer>';
  return $resultat;
}
function fragmentAbaixDeTot($codiLlengua){
	$resultat = '  <section class="copyright py-4 text-center text-white">
    <div class="container">
      <small>Gracias por confiar en nuestros servicios de EuroIMG!</small>
    </div>
  </section>';
  return $resultat;
}
?>