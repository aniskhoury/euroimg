<?php
/*  #######################################################
	##      Textos de la web per diferents llengues      ##
	#######################################################
	##               Autor: Anïs Khoury Ribas            ##
	##               Per Meinsa Sistemas S.L.            ##
	#######################################################
/*Obtenim la llengua de l'usuari*/
$llengua       = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
/*
	###########################
	### Codis dels idiomes  ###
	###########################
	Web: https://www.metamodpro.com/browser-language-codes
	
	Principals llengues de EuroIMG:
	ca -> català
	eu -> euskera
	gl -> gallec
	po -> portuguès
	it -> italià
	fr -> francès
	de -> alemany
	ga -> irlandès
	el -> grec
	nl -> holandès
	
	en -> anglès
*/
$codisLlengues  = ["ca"=>0, "eu"=>1,"gl"=>2,"po"=>3,"it"=>4, "fr"=>5,"de"=>6,"ga"=>7, "el"=>8,"nl"=>9,"es"=>10];
$codiLlengua   = 0;

if (isset($codisLlengues[$llengua])){
	$codiLlengua = $codisLlengues[$llengua];
}

$missatges[0]["titol"] = "EuroIMG - Web per pujar imatges";
$missatges[1]["titol"] = "EuroIMG - irudiak igotzeko web";
$missatges[2]["titol"] = "EuroIMG - Web para cargar imaxes";
$missatges[3]["titol"] = "EuroIMG - web para fazer upload de imagens";
$missatges[10]["titol"] = "EuroIMG - Web para subir imagenes";


?>